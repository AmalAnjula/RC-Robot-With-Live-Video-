package com.ainven.robcontoller;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.media.Image;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageView;
import android.view.MotionEvent;
import android.widget.TextView;
import android.widget.Toast;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Set;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Set;
import java.util.UUID;import java.util.Timer;
import java.util.TimerTask;


public class MainActivity extends AppCompatActivity {

    BluetoothAdapter mBluetoothAdapter;
    BluetoothSocket mmSocket;
    BluetoothDevice mmDevice;
    OutputStream mmOutputStream;
    InputStream mmInputStream;
    Thread workerThread;
    byte[] readBuffer;
    int readBufferPosition;
    int counter;
    volatile boolean stopWorker;

    float L_SP = 0, R_SP = 0, BASE_SP = 0, ERR = 0, ERR_R = 0;
    String outdata = "";
    TextView T1, touchTxt;
    float x = 0f;
    float y = 0f;
    TextView ipTxt;
    TextView stlbl;
    String servo = "0";
    float imgXX, imgYY, imgH, imgW, ballW, ballH, ballX, ballY;
    ImageView imgV, IMGball;
    ImageView up, left, right, down;

    String blueOutData = "";
    Button BlueBtn;
boolean blueConOk=false;
    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            this.getSupportActionBar().hide();
        } catch (NullPointerException e) {
        }

        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);



        setContentView(R.layout.activity_main);
          BlueBtn = findViewById(R.id.bluBtn);

        Date c = Calendar.getInstance().getTime();
        System.out.println("Current time => " + c);
        SimpleDateFormat df = new SimpleDateFormat("MM", Locale.getDefault());
        String formattedDate = df.format(c);

        Log.d("Date>>>",formattedDate);

        int Month=Integer.parseInt(formattedDate);

        if(Month!=2){
            BlueBtn.setEnabled(false);
            int duration = Toast.LENGTH_LONG;

            Toast toast = Toast.makeText(getApplicationContext(), "Please active.\r\nContact email: info@ainven.com", duration);
            toast.show();

        }


        up = findViewById(R.id.imageViewup);
        down = findViewById(R.id.imageViewdown);
        left = findViewById(R.id.imageViewleft);
        right = findViewById(R.id.imageViewright);


        imgV = findViewById(R.id.imageView);
        IMGball = findViewById(R.id.imageView2);

        stlbl = findViewById(R.id.st_lbl);

        T1 = (TextView) findViewById(R.id.textView2);
        touchTxt = (TextView) findViewById(R.id.textView3);

        Button loadBtn = findViewById(R.id.loadBtn);
        final WebView wv = findViewById(R.id.webView);

        ipTxt = findViewById(R.id.iptxt);


        WebView newWebView = new WebView(this);

        wv.setWebViewClient(new MyBrowser());


        BlueBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                try {
                    findBT();
                    openBT();
                } catch (Exception ee) {

                }
               // updateBtn();

            }
        });


        loadBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //   WebSettings webSettings = wv.getSettings();
                // webSettings.setJavaScriptEnabled(true);

                wv.getSettings().setLoadsImagesAutomatically(true);
                wv.getSettings().setJavaScriptEnabled(true);
                wv.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
                wv.loadUrl(ipTxt.getText().toString());

                wv.getSettings().setUseWideViewPort(true);
                wv.getSettings().setLoadWithOverviewMode(true);
                //  Toast.makeText( "sdfs","done", Toast.LENGTH_SHORT).show();
            }
        });


        up.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                if (event.getAction() == MotionEvent.ACTION_UP) {
                    servo = "0";
                } else {
                    servo = "U";
                }
                stateUpdate();
                return true;
            }
        });

        down.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    servo = "0";
                } else {
                    servo = "D";
                }
                stateUpdate();
                return true;
            }
        });

        left.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    servo = "0";
                } else {
                    servo = "L";
                }
                stateUpdate();
                return true;
            }
        });
        right.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    servo = "0";
                } else {
                    servo = "R";
                }
                stateUpdate();
                return true;
            }
        });

        imgV.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                final float x = event.getX();
                final float y = event.getY();
                float lastXAxis = x;
                float lastYAxis = y;

                ballH = IMGball.getHeight();
                ballW = IMGball.getWidth();
                ballX = IMGball.getX();
                ballY = IMGball.getY();


                imgXX = imgV.getX();
                imgYY = imgV.getY();
                imgW = imgV.getWidth();
                imgH = imgV.getHeight();


                if (event.getAction() == MotionEvent.ACTION_UP) {


                    IMGball.setX(imgXX + (imgW / 2) - (ballH / 2));
                    IMGball.setY(imgYY + (imgH / 2) - (ballW / 2));
                    BASE_SP = 0;
                    ERR = 0;
                } else if (lastXAxis > 0 && lastYAxis > 0 && lastYAxis < imgH && lastXAxis < imgW) {

                    IMGball.setX(lastXAxis + imgXX - (ballH / 2));
                    IMGball.setY(lastYAxis + imgYY - (ballW / 2));
                    BASE_SP = lastYAxis - (imgH / 2);
                    ERR = lastXAxis - (imgW / 2);
                }



                L_SP = BASE_SP + ERR;
                R_SP = BASE_SP - ERR;
                L_SP = L_SP * -1;
                R_SP = R_SP * -1;
                //L_SP=L_SP/((imgW/2))*255;
                //R_SP=R_SP/((imgH/2))*255;

                float main_sp = 0;

             //  Log.d("L_SP R_SP B_SP ERR", String.valueOf(L_SP)+"  "+ String.valueOf(R_SP)+"   "+String.valueOf(BASE_SP)+"   "+String.valueOf(ERR));

                //  //  T1.setText(String.format("x1=%s  x2=%s y1=%s y2=%s w=%s h=%s",  imgXX, imgXX+imgW,imgYY,imgYY+imgH,imgW,imgH));
                //  touchTxt.setText(String.format("x=%s  y=%s"  ,lastXAxis ,lastYAxis));
               /* String  outdata1 = "[,";
                outdata1+=String.format("%.1f", L_SP);
                outdata1+=",";
                outdata1+=String.format("%.1f", L_SP);
                outdata1+=",";
                outdata1+=servo;
                outdata1+=",]";
               T1.setText(outdata1);*/
                stateUpdate();
                return true;
            }
        });


    }


    void stateUpdate() {

         String  outdata1 = "[,";
            outdata1+=String.format("%.1f", L_SP);
            outdata1+=",";
            outdata1+=String.format("%.1f", R_SP);
            outdata1+=",";
            outdata1+=servo;
            outdata1+=",]";

            T1.setText(outdata1);
        }
    public class TimerTaskExample {
        Timer timer;

        public TimerTaskExample(int seconds) {
            timer = new Timer();
            timer.schedule(new Reminder(), 0, // initial delay
                    seconds * 200); // subsequent rate
        }

        class Reminder extends TimerTask {


            public void run() {
                try {
                    sendData();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                //   System.out.println("Knock Knock..!");
            }
        }
    }


    void openBT() throws IOException
    {
        UUID uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"); //Standard SerialPortService ID
        mmSocket = mmDevice.createRfcommSocketToServiceRecord(uuid);
        mmSocket.connect();
        mmOutputStream = mmSocket.getOutputStream();
        mmInputStream = mmSocket.getInputStream();

        beginListenForData();

        stlbl.setText("Bluetooth Opened");
    }

    void closeBT() throws IOException
    {
        stopWorker = true;
        mmOutputStream.close();
        mmInputStream.close();
        mmSocket.close();
        stlbl.setText("Bluetooth Closed");
    }

    void sendData() throws IOException {
          outdata = "[,";
        outdata+=String.format("%.1f", L_SP);
        outdata+=",";
        outdata+=String.format("%.1f", R_SP);
        outdata+=",";
        outdata+=servo;
        outdata+=",]";

        outdata+="\r\n";

       //


        try{
            mmOutputStream.write(outdata.getBytes());
           // blueConOk=true;
            Log.d("Blue sent", outdata);
        }
        catch ( Exception ttr){
          //  blueConOk=false;

        }

      //  mmOutputStream.write(tt);
        // stlbl.setText("Data Sent");
       // outStream = btSocket.getOutputStream();
    }

    void updateBtn(){
        try{

            if(blueConOk==true){
                BlueBtn.setText("Disconnect");
            }
            else{
                BlueBtn.setText("Connect");
                closeBT();
            }
        }
        catch ( Exception yy){

        }


    }
    void findBT()
    {
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if(mBluetoothAdapter == null)
        {

            stlbl.setText("No bluetooth adapter available");
        }

        if(!mBluetoothAdapter.isEnabled())
        {
            Intent enableBluetooth = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBluetooth, 0);
        }

        Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();
        if(pairedDevices.size() > 0)
        {
            for(BluetoothDevice device : pairedDevices)
            {
                String nowCheckDevice=device.getName();
                TextView blueName=findViewById(R.id.blueTxt);

                Log.d("blueName>",nowCheckDevice);
                String des_blue=  blueName.getText().toString();
                Log.d("sedBlueName>",des_blue);

                if (des_blue.length()==0){
                    blueName.setText("NoName");
                }
                Log.d("blueTxt>",des_blue);
                if(nowCheckDevice.equals(des_blue))
                {
                    mmDevice = device;
                    new TimerTaskExample(1);

                    break;
                }
            }
        }
        stlbl.setText("Bluetooth Device Found");
    }


    void beginListenForData()
    {


    }

    void getTOuch(){

    }


}


